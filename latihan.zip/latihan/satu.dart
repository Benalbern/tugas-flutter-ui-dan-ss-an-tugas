import 'package:flutter/material.dart';

// Fungsi utama untuk menjalankan aplikasi
void main() {
  runApp(const MyApp());
}

// Widget utama aplikasi
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Layout Demo',
      // Menghilangkan banner debug
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Strawberry Pavlova'),
        ),
        // Menggunakan widget Satu sebagai body
        body: const Satu(),
      ),
    );
  }
}

// Widget class Satu yang Anda berikan, sekarang diisi dengan layout
class Satu extends StatelessWidget {
  const Satu({super.key});

  @override
  Widget build(BuildContext context) {
    // Bagian Judul
    const titleSection = Text(
      'Strawberry Pavlova',
      textAlign: TextAlign.center,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 24,
      ),
    );

    // Bagian Deskripsi
    const descriptionSection = Text(
      'Pavlova is a meringue-based dessert named after the Russian ballerina Anna Pavlova. Pavlova features a crisp crust and soft, light inside, topped with fruit and whipped cream.',
      textAlign: TextAlign.center,
      softWrap: true,
      style: TextStyle(
        fontSize: 16,
      ),
    );

    // Bagian Peringkat (Ratings)
    final stars = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.star, color: Colors.green[500]),
        Icon(Icons.star, color: Colors.green[500]),
        Icon(Icons.star, color: Colors.green[500]),
        const Icon(Icons.star, color: Colors.black),
        const Icon(Icons.star, color: Colors.black),
      ],
    );

    final ratings = Container(
      padding: const EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          stars,
          const Text(
            '170 Reviews',
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.w800,
              fontFamily: 'Roboto',
              letterSpacing: 0.5,
              fontSize: 20,
            ),
          ),
        ],
      ),
    );

    // Bagian Informasi (Prep, Cook, Feeds)
    // Helper function untuk membuat kolom informasi
    Column buildInfoColumn(String title, String subtitle, IconData icon) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.green[500]),
          Container(
            margin: const EdgeInsets.only(top: 8),
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: Colors.grey,
              ),
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: Colors.grey,
            ),
          ),
        ],
      );
    }

    final infoSection = Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        buildInfoColumn('PREP', '25 min', Icons.kitchen),
        buildInfoColumn('COOK', '1 hr', Icons.timer),
        buildInfoColumn('FEEDS', '4-6', Icons.restaurant),
      ],
    );

    // Gabungkan semua bagian dalam satu Column utama
    // Widget Material ditambahkan untuk memastikan text style
    // di-render dengan benar dan menghilangkan garis bawah kuning di debug mode.
    return Material(
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(16.0),
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black, width: 1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min, // Agar container menyesuaikan ukuran child
            children: [
              titleSection,
              const SizedBox(height: 8),
              descriptionSection,
              const SizedBox(height: 8),
              ratings,
              const SizedBox(height: 8),
              infoSection,
            ],
          ),
        ),
      ),
    );
  }
}

